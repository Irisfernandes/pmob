package com.example.iris09

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
